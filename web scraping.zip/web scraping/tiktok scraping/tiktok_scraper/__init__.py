# from base import Module
# from .scrape_tiktok import scrape_tiktok_account_from_source, scrape_tiktok_urls_from_source, create_driver_scrape_tiktok_account

# TIKTOK = Module(
#     "tiktok",
#     ["https://www.tiktok.com/@(username)/video/(video_id)"],
#     create_driver_scrape_tiktok_account,
#     scrape_tiktok_urls_from_source)

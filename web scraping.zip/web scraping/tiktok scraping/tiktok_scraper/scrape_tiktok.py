"""
This script checks if there are any new videos updated by a tiktok user after a given date and time,
and returns a list of dictionaries containing the video link and information about the upload.

Usage:
    python scriptv3.2.2.py
"""
import os
import re
import time
import json
import random
import requests
import math
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List
from bs4 import BeautifulSoup
from datetime import datetime, timedelta



# Scraping with selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    WebDriverException, TimeoutException,
    NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException)

from .tiktok_captcha import solve_captcha_if_present
from .chrome_utils import create_driver
# from logging_comfig import TT_Pub_AM_c_logger as logger
# from tiktok_captcha import solve_captcha_if_present
# from chrome_utils import create_driver

import logging as logger
# logger = logging.getLogger(__name__)

MODULE_PATH = os.path.dirname(os.path.abspath(__file__))

def display_inc(old, new):
    """Displays the percentage increase rounded to 0.5% if <100% and nearest integer if > 1--%."""
    
    if isinstance(old, str) or isinstance(new, str):
        old = int(old)
        new = int(new)

    if old == -1 or new == -1:
        return ""
    
    old, new = int(old), int(new)
    if old == 0:
        return "0.0%"
    perc_inc = ((new - old) / old) * 100
    perc_inc = math.floor(perc_inc / 0.5) * 0.5

    if perc_inc >= 100:
        return f"{int(perc_inc)}%"
    elif perc_inc >= 0.5:
        return f"{perc_inc}%" 
    else:
        return "0.0%"

# --- Scraping from account page source without Selenium --- #
def scrape_tiktok_account_from_source(username: str, since_datetime: datetime = None, max_posts=30):
    """
    Main Tiktok account scraper. Gets all details from page source (HTTP request).

    Fields obtained:
    - link
    - date
    - views
    - likes
    - comments
    - shares

    Parameters
    ---
    username: str
    since_datetime: datetime = None
        if not provided, returns the last 5 posts in the past 365 days
    max_posts: int = 30

    Returns
    ---
    posts: List[Dict]
        each tiktok post contains the above fields
    """
    # logger.warning(f"scrape from tt source")
    print("hello from TT Account source")
    # If user does not specify a since_datetime, return most recent 5 posts in last 30 days
    if not since_datetime:
        since_datetime = datetime.now() - timedelta(days=365)
        max_posts = 5

    posts = []
    user_profile_url = f'https://www.tiktok.com/@{username}'

    # GET user profile, max 3 attempts
    attempts, status_code = 0, 0
    while status_code != 200 and attempts < 3:
        response = requests.get(user_profile_url)
        if (status_code := response.status_code) != 200:
            attempts += 1
            logger.info(
                f"Attempt {attempts}/3: Could not get a HTTP response for {user_profile_url}")
    print(f"Status code: {status_code}")

    # Parse HTML and find script tag which has all the post information in json format
    soup = BeautifulSoup(response.text, 'html.parser')
    print(soup.prettify())
    script = soup.find("script", id="SIGI_STATE") ## this part 
    print(script)

    # Convert script json string to json object
    tiktok_json = json.loads(script.text)
    tiktok_json = tiktok_json['ItemModule']
    # Loop over each video id and its associated object
    for post_id, post_object in tiktok_json.items():
        # Obtain video time as UTC time and convert to local SG time
        video_utctime = post_object['createTime']
        utc_time = datetime.utcfromtimestamp(int(video_utctime)).strftime('%Y-%m-%d %H:%M:%S')
        pd_obj = datetime.strptime(utc_time, '%Y-%m-%d %H:%M:%S') + timedelta(hours=8)
        # caption = soup.find("div", {"data-e2e":"user-post-item-desc"}).find("a").get("title")
        # print(f"Found tiktok captions {caption}")

        # If current post time is before lmt, we can skip this and all older posts
        if pd_obj < since_datetime:
            break

        video_url = f"https://www.tiktok.com/@{username}/video/{post_id}/"


        # Get each individual page to scrape caption
        driver = requests.get(video_url)
        driver_soup = BeautifulSoup(driver.text, 'html.parser')
        try:
            caption_text = driver_soup.find("h1", {"data-e2e":"browse-video-desc"})
            try:
                caption = caption_text.find("span").text
            except:
                caption = caption_text.get_text(separator=' ', strip= True)
        except:
            caption = ""


        stats = tiktok_json[post_id]['stats']
        like_count = stats['diggCount']
        share_count = stats['shareCount']
        comment_count = stats['commentCount']
        view_count = stats['playCount']

        post = {
            "text": f"{caption}",
            "link": f"{video_url}",
            "date": f"{pd_obj}",
            "likes": f"{like_count}",
            "comments": f"{comment_count}",
            "views": f"{view_count}",
            "shares": f"{share_count}"
        }
        posts.append(post)
        logger.info(f"Obtained Tiktok post: {json.dumps(post)}, since_datetime={since_datetime}")

        if len(posts) == max_posts:
            break

    logger.info(f"Tiktok posts retrieved for {username}.")
    save_csv_accounts(posts)
    return posts


# --- Scraping with Selenium driver + solve captcha if necessary --- #
def create_driver_scrape_tiktok_account(
        account: str, since_datetime: datetime = None, max_posts: int = 100):
    """
    Creates a chromedriver using a random user profile to scrape a particular account.
    After scraping, quit the driver so a new driver can be created in the next scrape.
    """
    # If user does not specify a since_datetime, return most recent 5 posts in last 30 days
    if not since_datetime:
        since_datetime = datetime.now() - timedelta(days=365)
        max_posts = 5

 
    try:
        driver = create_driver("TiktokACC")
        logger.info('Creating web driver for TiktokACC')
        print('Creating web driver for TiktokACC')
        print(f"date : {since_datetime} ({type(since_datetime)})")
        posts = _scrape_tiktok_account_with_driver(
            driver, username=account, since_datetime=since_datetime, max_posts=max_posts)
        logger.info(f"Tiktok posts retrieved for {account}, quitting driver.")
        driver.quit()
        return posts
    except WebDriverException:
        # Error creating driver
        logger.exception("WebDriverException")
    except AttributeError:
        # driver=None, most likely due to multiple chrome browsers open
        logger.exception(
            "Driver is None, likely issue with creating driver. "
            "Ensure all chrome browsers are closed.")
    except:
        logger.exception("Unexpected exception occurred when scraping Tiktok posts.")
        driver.quit()


def extract_id_and_type(url):
    # Regular expression pattern to extract ID and type of post
    pattern = r'https://www.tiktok.com/@[^/]+/(video|photo)/(\d+)'
    
    # Match the pattern against the URL
    match = re.match(pattern, url)
    
    if match:
        post_type = match.group(1)
        post_id = match.group(2)
        return post_id, post_type
    else:
        return None, None

def click_next(driver):
    # check if the arrow-right button to go to next post exist
    next_button = driver.find_element(
        By.XPATH, '//button[@data-e2e="arrow-right"]')

    # generate random value to let program sleep, to wait for page to load
    random_float = random.uniform(0.10, 1.00)
    time.sleep(random_float)

    if next_button.is_enabled():  # if next button is enabled
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable(
            (By.XPATH, '//button[@data-e2e="arrow-right"]'))).click()
        logger.info('clicked on next post')
        try:
            time.sleep(1)
            login_container = driver.find_element(By.XPATH, "//div[contains(text(), 'Continue as guest')]")
            if login_container is not None:
                print('###########loginContainer')
                login_container.click()
        except NoSuchElementException:
            pass
        print('clicked on next post') 
    
    return next_button.is_enabled()
    
def _scrape_tiktok_account_with_driver(
        driver: webdriver.Firefox, username, since_datetime: datetime, max_posts=5):
    """
    This function gets details of new tiktok uploads (upload link, upload date, number of likes and comments).

    Parameters:
    -------
    profile_directory_list: list
        The list of chrome profiles to select from

    Returns
    -------
     driver : Chrome WebDriver object

    username : str
        The tiktok user to monitor

    since_datetime: str
        Date of last monitored time, as a string, in UTC format (eg: '2023-02-28T16:24:18.000Z')

    max_post_to_return: int, optional
        Maximum number of post to return. (Eg: if there are 50 new post, but max_post_to_return is set to 30, only the 30 most recent post will be returned.)
        By default, max_post_to_return is set to -1, which indicates there is no max limit set. The function will return all posts that are posted after the last monitored date.

    Returns
    -------
    post_links : list
        The list of json objects. Each json object contains the details of one tiktok post.
        Fields: link, date, likes (count), comments (count)
    ```
    Sample payload:
    [
        {'link': 'https://www.tiktok.com/@raymondl88/video/7210632777077706002', 'date': '2023-03-15 04:57:50', 'likes': '42', 'comments': '10'},
        ...
    ]
    ```

    Raises
    ------
    StaleElementReferenceException
        If an element reference is stale (i.e., no longer attached to the DOM).
    NoSuchElementException
        If an element could not be found on the page.
    TimeoutException
        If an operation times out before completion.
    WebDriverException
        If a general WebDriver error occurs that does not fit into any other exception category.
    """
    try:
        user_profile_url = f'https://www.tiktok.com/@{username}'
        posts = []

        driver.get(user_profile_url)
        time.sleep(3)

        # ensure chrome is active window so captcha can be solved
        # NOTE: fails sometimes
        driver.switch_to.window(driver.window_handles[0])

        # # scroll up and down to pass time
        # random_length_1 = random.randint(100, 150)
        # random_length_2 = random.randint(50, 100)
        # driver.execute_script(f"window.scrollBy(0, {random_length_1})")
        # driver.execute_script(
        #     f"window.scrollBy({random_length_1}, {random_length_2})")
        # driver.execute_script(
        #     f"window.scrollBy({random_length_1 + random_length_2}, 0)")

        # check for captcha and solve if present
        logger.debug("Checking for Tiktok captcha")
        # solve_captcha_if_present(driver)
        time.sleep(5)

        # click on first post
        print("Attempting to click on first post")
        time.sleep(2)
        try:
            element = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(
                (By.XPATH, f"(//a[contains(@href, 'https://www.tiktok.com/@{username}/video/')])[1]//strong")))
        except TimeoutException as e:
            print("Element timed out!")
            # If element is not clickable, we remove the popup
 
            # The popup should have a div with innerHTML being Continue as guest
            print("Trying to find popup...\n")
            time.sleep(2)
            try:
                popup = driver.find_element(By.XPATH, "//div[contains(text(), 'Continue as guest')]")
                popup.click()
                print("Popup clicked!\n\n")
            except NoSuchElementException:
                pass
            
            time.sleep(2)
            
            e = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(
                (By.XPATH, f"(//a[contains(@href, 'https://www.tiktok.com/@{username}/video/')])[1]//strong")))
            
        
        post_elements = driver.find_elements(By.XPATH, f"//a[not(@title) and contains(@href, 'https://www.tiktok.com/@{username}/video/')]")
        # print( len(post_elements))
        for post_element in post_elements:
            post_text = post_element.text
            print("\nhref:", post_element.get_attribute("href"))

            if "Pinned" in post_text:
                print("this is a pinned post, skipping...")
                continue
            else:
                print("Not pinned, breaking...")
                # Scroll the element into view using JavaScript
                video_element = post_element
                break
        
        driver.execute_script("arguments[0].scrollIntoView(true);", video_element)
        
        try:
            strong_element = video_element.find_element(By.XPATH, ".//strong")
        except:
            print("strong element error")
        else:
            time.sleep(random.uniform(1, 3))
            strong_element.click()

            
        

        # get url of first post
        WebDriverWait(driver, 10).until(EC.url_contains(
            f"https://www.tiktok.com/@{username}/video/"))
        
        # convert URL object to a string object
        current_url = str(driver.current_url)
        post_id, post_type = extract_id_and_type(current_url)
        print(f"1st round url is: {current_url}\n id: {post_id}, type: {post_type}")
        if post_type == 'photo':
            click_next(driver)
        else:
            video_url = current_url

        

        # get json from page source
        print("Obtaining Tiktok json")
        tiktok_json = _get_tiktok_json(video_url)
        # print(tiktok_json)

        # get video id
        splitted_url = video_url.rsplit("/", 1)
        video_id = splitted_url[-1]

        # get timestamp from json
        unix_timestamp = int(tiktok_json['createTime'])
        logger.debug('first post, using json to get timestamp')

        # convert to utc
        utc_time = datetime.fromtimestamp(
            unix_timestamp).strftime('%Y-%m-%d %H:%M:%S')

        # create datetime objects for comparison
        # last monitored time datetime object
        # lmt_obj = datetime.strptime(
        #     since_datetime.strftime('%Y-%m-%dT%H:%M:%S.%f'), '%Y-%m-%dT%H:%M:%S.%f')
        lmt_obj = since_datetime
        logger.info(f'last monitored time datetime object: {lmt_obj}')
        # first post date datetime object in utc time
        pd_obj = datetime.strptime(utc_time, '%Y-%m-%d %H:%M:%S') 

        
        # get caption text
        try:
            caption = tiktok_json['desc']  
        except:
            caption = ""
            logger.info(f"No captions found for {video_url}")

        print("tiktok_json",  type(tiktok_json))
        stats = tiktok_json['stats']
        # get likes count
        likes = stats['diggCount']
        share_count = stats['shareCount']
        comments = stats['commentCount']
        view_count = stats['playCount']

        print(
            f'video url: {video_url} \nvideo id: {video_id} \nlast monitored time: {lmt_obj} \npost date: {pd_obj} \nlikes: {likes} \ncomments: {comments}')
        while True: # pd_obj > lmt_obj:
            # append link, date, like count, comments
            post_id, post_type = extract_id_and_type(video_url)
            post = {
                "post_id": post_id, 
                "post_type": post_type, 
                "content": f"{caption}",
                "link": f"{video_url}",
                "post_date": f"{pd_obj}",
                "likes": likes,
                "comments": comments,
                "views": view_count,
                "shares": share_count
            }
        
            if post_type == "video":
                posts.append(post)
            logger.info(f"Obtained Tiktok post: {json.dumps(post)}, since_datetime={since_datetime}")


            if max_posts > 0 and len(posts) >= max_posts:
                logger.info(
                    f'number of new post has reached {max_posts}')
                print(f'number of new post has reached {max_posts}')
                break
                
            next_button_enabled = click_next(driver)
            print('next_button_enabled', next_button_enabled)
            if next_button_enabled:
                print("next")
                
                pass
            elif not next_button_enabled:  # if next button is disabled
                logger.info(
                    'current post is the last post. User has no more post')
                return posts
            else:
                logger.info('There is an error accessing next post.')
                return posts

            # get url of next post
            # convert URL object to a string object
            video_url = str(driver.current_url)
            

            post_id, post_type = extract_id_and_type(video_url)
            print(f"\nlooping url is: {video_url}\n id: {post_id}, type: {post_type}")
            if post_type == 'photo':
                next_button_enabled = click_next(driver)
                if next_button_enabled:

                    continue
                elif not next_button_enabled:  # if next button is disabled
                    logger.info(
                        'current post is the last post. User has no more post')
                    return posts
                else:
                    logger.info('There is an error accessing next post.')
                    return posts
           

            logger.debug("Obtaining Tiktok json")
            tiktok_json = _get_tiktok_json(video_url)
            if tiktok_json is None:
                try:
                    login_container = driver.find_element(By.XPATH, "//div[contains(text(), 'Continue as guest')]")
                    if login_container is not None:
                        login_container.click()
                    else:
                        print('###########notfound2')
                except NoSuchElementException:
                    print('###########notfound')
                    pass
                tiktok_json = _get_tiktok_json(video_url)
            # get video id
            splitted_url = video_url.rsplit("/", 1)
            video_id = splitted_url[-1]

            # if the post can be extracted using the json - must be within recent 30
            try:
                # get timestamp from json
                unix_timestamp = int(
                    tiktok_json['createTime'])
            except KeyError:
                # get unix timestamp from video id as not within the most recent 30 post
                logger.debug(
                    'post id not in json, using video id to get timestamp')
                # Right shift by 32 bits to get the 32 most significant bits,
                # which represents the unix timestamp
                unix_timestamp = int(video_id) >> 32
            except Exception as e:
                logger.exception(
                    "An error occurred when trying to find post date:", str(e))
            else:
                logger.debug(
                    'post id exists in json, using json to get timestamp')
            try:
                caption = tiktok_json['desc']  
            except Exception as e:
                print(e)
                caption = ""
                logger.info(f"No captions found for {video_url}")

            # convert to utc
            utc_time = datetime.fromtimestamp(
                unix_timestamp).strftime('%Y-%m-%d %H:%M:%S')

            # create datetime object for next post
            pd_obj = datetime.strptime(utc_time, '%Y-%m-%d %H:%M:%S') 
            logger.debug(f'post {len(posts) + 1} date: {pd_obj}')

            stats = tiktok_json['stats']
            # get likes count
            likes = stats['diggCount']
            share_count = stats['shareCount']
            comments = stats['commentCount']
            view_count = stats['playCount']

            logger.info(
                f'video url: {video_url} \nvideo id: {video_id} \nlast monitored time: {lmt_obj} \npost date: {pd_obj} \nlikes: {likes} \ncomments: {comments}')
            print(
                f'video url: {video_url} \nvideo id: {video_id} \nlast monitored time: {lmt_obj} \npost date: {pd_obj} \nlikes: {likes} \ncomments: {comments}')
           
    except StaleElementReferenceException as se:
        logger.exception(f'scrape_tiktok_post StateElementRef Exception: {se}')
    except NoSuchElementException as ne:
        logger.exception(f'scrape_tiktok_post NoSuchElement Exception: {ne}')
    except TimeoutException as te:
        logger.exception(f'scrape_tiktok_post Timeout Exception: {te}')
    except WebDriverException as we:
        logger.exception(f'scrape_tiktok_post WebDriver Exception: {we}')
    else:
        # driver.get("chrome://newtab")
        return posts

def _get_tiktok_json(url, save_file=True):
    """
    Returns a json object mapping each video_id to a dictionary,
    where keys such as `createTime`, `stats` will be accessed.
    """
    #get json from page source
    #Get the page source
    try:
        # GET user profile, max 5 attempts
        attempts, status_code = 0, 0
        while status_code != 200 and attempts < 5:
            headers = {
                # 'user-agent' : 'compatible;Baiduspider/2.0; +http://www.baidu.com/search/spider.html'
                'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
            response = requests.get(url, headers=headers)

            if (status_code := response.status_code) != 200:
                print("******* line 587 \n",e)
                logger.info(f"Attempt {attempts}/3: Could not get a HTTP response for {url}")
                attempts += 1
            else:
                print(f'{url} - response was success')
    except Exception as e:
        print("******* line 592 \n",e)
        print(f"Error retrieving {url}")
        return
    try:
        # time.sleep(1)
        # elem = driver.find_element("xpath", "//*")
        # source_code = elem.get_attribute("outerHTML")
        # Parse HTML and find script tag which has all the post information in json format
        soup = BeautifulSoup(response.text, 'html.parser')
        try:
            script = soup.find("script", id="__UNIVERSAL_DATA_FOR_REHYDRATION__")
            
            if script is None:
                with open('/home/s4q1/Desktop/crash.html', 'w') as file:
                    file.write(response.text)
                print(f"/////////////////TT Script for {url}: is None")
                print(response.text)
                logger.error(f"TT Script for {url}: is None")
                return
            else : logger.info(f"TT Script for {url}: is not None")

            # Convert script json string to json object
           
            tiktok_json = json.loads(script.text)
            with open('/home/s4q1/Desktop/crash.json', 'w') as file:
                    file.write(script.text)
            tiktok_json = tiktok_json['__DEFAULT_SCOPE__']['webapp.video-detail']['itemInfo']['itemStruct']

            # save json into file
            if save_file:
                tiktok_filepath = os.path.join(MODULE_PATH, "tiktok.json")
                with open(tiktok_filepath, 'w') as f:
                    json.dump(tiktok_json, f)

            return tiktok_json
        except Exception as e:
                #print(f"JSON element not found in tiktok link: {url}",e)
                logger.debug(f"JSON element not found in tiktok link: {url}")
                caption_text = soup.find("h1", {"data-e2e":"browse-video-desc"}) 
                if caption_text is None:
                    logger.exception(f"Page has issues: {url}")
                    return
                try:
                    # Tiktok format 1
                    article = soup.find("div", id="main-content-video_detail")
                    like_count = article.find("strong", {"data-e2e":"like-count"}).get_text()
                    comment_count = article.find("strong", {"data-e2e":"comment-count"}).get_text()
                    share_count = article.find("strong", {"data-e2e":"share-count"}).get_text()
                    caption_text = soup.find("h1", {"data-e2e":"browse-video-desc"})   
                    if caption_text is None:  
                        caption = ""
                        logger.info(f"No captions found for {url}")  
                    else:                   
                        caption = caption_text.find("span").text
                        logger.info(f"Found tiktok captions {caption}")
                except Exception as e:
                    # Tiktok format 2 (caption text not searched again as it is the same path)
                    like_count = soup.find("strong", {"data-e2e":"browse-like-count"}).get_text()
                    comment_count = soup.find("strong", {"data-e2e":"browse-comment-count"}).get_text()
    except Exception as e:
            logger.exception(f"Error scraping {url}: {e}")
            return
    


def _test_tiktok_xpath_validity(
        driver, user='work1234567890987654321', last_monitored_time='2023-01-01T05:48:43.000Z', expected_results=[{'link': 'https://www.tiktok.com/@work1234567890987654321/video/7216540789315357953', 'date': '2023-03-31 03:05:34', 'likes': '0', 'comments': '0'}]):
    # open driver using a fixed chrome profile
    # go to one tiktok acct
    # scrape the posts as usual
    # shld return the expected json
    for result in expected_results:
        if 'likes' in result:
            result['likes'] = 0
        if 'comments' in result:
            result['comments'] = 0

    try:
        actual_results = _scrape_tiktok_account_with_driver(driver, user, last_monitored_time)
    except Exception as e:
        logger.info(f'Sanity Check failed, Error: {e}')
    else:
        logger.info('Sanity Check passed.')
        for result in actual_results:
            if 'likes' in result:
                result['likes'] = 0
            if 'comments' in result:
                result['comments'] = 0
    finally:
        driver.quit()

    if actual_results == expected_results:
        logger.info(actual_results)
        logger.info(expected_results)
        return True

    return False


# --- Unit tests --- #
def _test_accounts():
    from selenium.webdriver import  Firefox, Chrome
    from selenium.webdriver.firefox.service import Service as FirefoxService
    from selenium.webdriver.firefox.options import Options as FirefoxOptions

    ser = FirefoxService()
    op = FirefoxOptions()
    op.add_argument("--incognito")
    op.page_load_strategy = 'normal'
    driver = Firefox(service=ser, options=op)

    since_datetime = datetime.now() - timedelta(minutes=180)
    account = 'mothershipsg'
    # posts = scrape_tiktok_account_from_source(account, since_datetime)
    
    posts = _scrape_tiktok_account_with_driver(driver,account, since_datetime)
    # posts = create_driver_scrape_tiktok_account(account)


    print(f"outcome of posts {posts}")

    driver.quit()
    # create_csv_accounts(results, csv_file)
    account_csv_file = 'tiktok_account_data.csv'
    # df = save_csv_accounts(posts, account_csv_file)
    # print(df)

def save_csv_accounts(data):
    csv_path = "./data/tiktok_acc_ez.csv"

    if os.path.isfile(csv_path):
        df = pd.read_csv(csv_path)
    else:
        df = pd.DataFrame()

    new_df = pd.DataFrame(data)
    new_df.insert(0, 'platform', 'tiktok')
    new_df.insert(1, 'scrape_time', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    #new_df['views'] = '0'
    df = pd.concat([df, new_df], ignore_index=True)
    df.to_csv(csv_path, index=False)

    return df

def save_csv_posts(data):
    csv_path = "./tiktok_scraper/output/tiktok_post_ez.csv"
    new_df = pd.DataFrame(data)
    new_df['change in likes'] = ''
    new_df['change in comments'] = ''
    new_df['change in views'] = ''
    new_df['change in shares'] = ''
    new_df['percentage likes change'] = ''
    new_df['percentage comments change'] = ''
    new_df['percentage views change'] = ''
    new_df['percentage shares change'] = ''
    
    df = new_df[['platform', 'url', 'scrapetime', 'text', 'likes', 'comments', 'views', 'shares',
             'change in likes', 'change in comments', 'change in views', 'change in shares',
            'percentage likes change', 'percentage comments change', 'percentage views change', 'percentage shares change']]
    
    if os.path.isfile(csv_path):
        existing_df = pd.read_csv(csv_path)
        
        existing_urls = existing_df['url'].tolist()
        print(existing_urls)
        new_urls = df['url'].tolist()
        
        for url in new_urls:
            if url in existing_urls:
                existing_row = existing_df.loc[existing_df['url'] == url]
                existing_row = existing_row.iloc[[-1]]
                existing_values = existing_row[['likes', 'shares', 'views', 'comments']].fillna(0).astype(float).values.flatten()
                new_values = new_df.loc[new_df['url'] == url, ['likes', 'shares', 'views', 'comments']].fillna(0).astype(float).values.flatten()
                print(existing_values)
                print(new_values)
                
                for i, col in enumerate(['likes', 'shares', 'views', 'comments']):
                    change_value = new_values[i] - existing_values[i]
                    change_percentage =  display_inc(existing_values[i], new_values[i])
                    df.loc[df['url'] == url, f'change in {col}'] = change_value
                    df.loc[df['url'] == url, f'percentage {col} change'] = change_percentage
                
        updated_df = pd.concat([existing_df, df])
        print(updated_df)
    else:
        updated_df = df
        print(updated_df)

    updated_df.to_csv(csv_path, index=False, na_rep='0')

def main():
    """Unit tests"""
    # logger.info('Performing Sanity Check')
    # driver = create_driver(CHROMEDRIVER_PATH, USER_DATA_DIR, user_profile)
    # test_passed = test_tiktok_xpath_validity(driver=driver)
    # print("Test passed:", test_passed)
    print("testing ground")

    account = 'htxsg'
    account = 'mothershipsg'
    last_updated = datetime.now() - timedelta(hours=24)
    # last_updated = datetime(2024, 4, 1)
    posts =create_driver_scrape_tiktok_account(account, last_updated)
    print(posts)
    # create_driver_scrape_tiktok_account(account)
    # _test_accounts()
    # _test_urls()



if __name__ == "__main__":
    main()

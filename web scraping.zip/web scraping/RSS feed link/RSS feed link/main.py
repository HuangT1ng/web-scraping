from rss_link_utils import *
from time import sleep
import pandas as pd
import logger
def main():
	# Load the CSV into a DataFrame
	df = pd.read_csv('NewsCatcher_sources.csv')	
	driver = initialize_chrome_driver()
 

 
	for index in range(28224, 50000):
		df = pd.read_csv('NewsCatcher_sources.csv')	

		query = df.iloc[index]['clean_url']

		try:
			# Get links for the current URL using the provided function
			links = get_links(query, driver)
			if links == "[]" or links == []:
				url = f"https://{df.iloc[index]['clean_url']}/"
				
				# Call the function to get RSS links
				try:
					links = get_rss_links(url, driver)
					print(f"Index:{index} completed with {len(links)} links found")
				except Exception as e:
					print(f"Error at index {index}: {e}")				
			# Store the links in the 'links' column
			links = list(set(links))
			df.at[index, 'links'] = str(links)  # Convert list to string for storing in CSV
			df.to_csv('NewsCatcher_sources.csv', index=False)

			print(f'Index:{index} completed')

		except Exception as e:
			print(f"Error processing URL '{query}': {e}")
			df.at[index, 'links'] = "Error"
    

def get_links(query, driver):
    keyword = get_part_before_first_dot(query)
    
    url = format_url(query)
    driver.get(url)
    
    links = extract_rss_links(driver,keyword)

    return links
    
if __name__ ==  "__main__" :
    main()
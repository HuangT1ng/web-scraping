import os
import shutil

# give access to enter key, esc key, etc. to type smth in search bar
from selenium.webdriver import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# to add more specific exceptions if needed
from selenium.common.exceptions import TimeoutException, NoSuchElementException

import time
import logging

import cv2
import urllib.request
import pyautogui
import numpy as np

# Path to tiktok folder
MODULE_PATH = os.path.dirname(os.path.abspath(__file__))

def solve_captcha_if_present(driver: Chrome):
    # captcha checker
    try:
        WebDriverWait(driver, 5).until(EC.visibility_of_all_elements_located(
            (By.XPATH, '//div[text()="Drag the slider to fit the puzzle"]')))
    except TimeoutException:
        logging.info("CAPTCHA WAS NOT PRESENT / CAPTCHA WAS NOT LOADED")
        return
    except:
        logging.exception("captcha check error")
        return
    else:
        # time.sleep(30)
        tiktok_captcha_bypass(driver, os.path.join(MODULE_PATH, "captcha_images"))


def tiktok_captcha_bypass(driver, folder_path):
    '''
    Function to bypass tiktok rotation captcha.

    Args:
        driver : the webdriver
        folder_path : path to save the details of the images for correction

    Returns:
        is_solved : boolean to check if captcha has been bypassed
    '''

    is_solved = False
    # Used to get the id of the captcha container
    element = driver.find_element(
        By.XPATH, '//div[contains(@class,"captcha")]')
    parent_element = element.find_element(By.XPATH, '..')
    xpath_id = parent_element.get_attribute('id')
    logging.debug(f"id is {xpath_id}")

    loop_counter = 0
    MAX_TIKTOK_BYPASS_ATTEMPT = 20
    MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT = 5
    WEBDRIVER_WAIT_TIME = 10

    # loop until max attempt
    while loop_counter < MAX_TIKTOK_BYPASS_ATTEMPT:
        logging.info("CAPTCHA PRESENT")

        # Find the elements of the 2 images of the captcha, refresh the image if not loaded
        for i in range(MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT):
            # Check if the outer image is loaded. Generally if the first image is loaded the inner image will also be loaded
            try:
                WebDriverWait(driver, 3).until(
                    EC.visibility_of_all_elements_located(
                        (By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[1]')))
            except TimeoutException:
                logging.debug("Captcha image loading timeout")

            # Find the element of the respective images for downloading
            try:
                captcha_outer_ring = driver.find_element(
                    By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[1]')
                captcha_inner_circle = driver.find_element(
                    By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[2]')
                break
            except NoSuchElementException:
                # Image to be refreshed if the element is not found
                logging.error("Captcha Image Xpath not found! Refreshing...")
                refresh_button = driver.find_element(
                    By.XPATH, f'//span[text()="Refresh"]')
                refresh_button.click()
            except BaseException:
                logging.exception("Unexpected Captcha Image Error")
                return is_solved
        else:
            logging.error(
                f"Could not find Captcha Image Xpath after {MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT} tries...")
            return is_solved

        img_tags = [captcha_outer_ring, captcha_inner_circle]
        img_path = []

        # Download the inner and outer image
        for i, img_tag in enumerate(img_tags):
            img_src = img_tag.get_attribute('src')

            # Filename for outering and innner circle respectively
            if i == 0:
                filename = os.path.join(folder_path, f'captcha_outer.png')
                filename_attempt = os.path.join(
                    folder_path, f'attempt_{loop_counter}_captcha_outer.png')
                img_path.append(filename)
            elif i == 1:
                filename = os.path.join(folder_path, f'captcha_inner.png')
                filename_attempt = os.path.join(
                    folder_path, f'attempt_{loop_counter}_captcha_inner.png')
                img_path.append(filename)
            else:
                # filename = os.path.join(folder_path,f'captcha_image_{i}.png')
                logging.error("unexpected number of images")
                return is_solved

            # Download the images using urlib
            try:
                urllib.request.urlretrieve(img_src, filename)
            except BaseException:
                logging.exception("Error downloading image")
                return is_solved

            # shutil.copy(filename, filename_attempt)

        # Angle correction & angle to pixel conversion
        best_angle, corrected_image_filename = _tiktok_captcha_rotate(
            img_path[0], img_path[1], folder_path)
        corrected_image_filename_attempt = os.path.join(
            folder_path, f'attempt_{loop_counter}_captcha_corrected.png')
        shutil.copy(corrected_image_filename, corrected_image_filename_attempt)
        pixel = _angle_to_pixel(best_angle)
        logging.info(f"Angle: {best_angle} degrees \t Pixel: {pixel} px")

        # Check if slider is ready
        try:
            slider = WebDriverWait(driver, WEBDRIVER_WAIT_TIME).until(EC.visibility_of_all_elements_located(
                (By.XPATH, '//div[@class="secsdk-captcha-drag-icon sc-kEYyzF fiQtnm"]')))
        except BaseException:
            logging.exception("error")
            return is_solved
        else:
            time.sleep(3)
            # Find slider element
            try:
                driver.find_element(
                    By.XPATH, '//*[@id="secsdk-captcha-drag-wrapper"]/div[2]/div')
            except BaseException:
                logging.exception("slider location error")
            else:
                # Find the sliding button and slide
                # slider_image = os.path.join(os.getcwd(), 'cfg', 'slider.png')
                slider_image = os.path.join(MODULE_PATH, 'slider.png')
                # slider_image = os.path.join(MODULE_PATH, 'slider_arrow.png')
                slider_location = pyautogui.locateCenterOnScreen(
                    slider_image, confidence=0.7)

                logging.info(f"Found slider at {slider_location}")
                # slider_location = None
                if slider_location is not None:
                    x, y = slider_location

                    # emulate mouse movement
                    pyautogui.moveTo(x, y)
                    pyautogui.mouseDown()
                    # pyautogui.dragTo(x + pixel, y, duration=5)
                    pyautogui.drag(pixel, 0, duration=3)
                    pyautogui.mouseUp()
                else:
                    logging.error("Unable to find slider")
                    return is_solved

        time.sleep(3)

        # Check if captcha still exists
        try:
            driver.find_element(By.XPATH, f'//*[@id="{xpath_id}"]/div')
        except NoSuchElementException:
            logging.info("Captcha cleared")
            is_solved = True
            return is_solved
        else:
            logging.info("Captcha still exists")
            loop_counter = loop_counter + 1

            if loop_counter % 5 == 0:
                logging.info("refreshing page")
                driver.refresh()
            if loop_counter >= MAX_TIKTOK_BYPASS_ATTEMPT:
                logging.error(
                    f"Captcha tried {MAX_TIKTOK_BYPASS_ATTEMPT} times, unable to solve...")
                return is_solved


def _angle_to_pixel(angle):
    '''
    To convert the angle given in to pixel. This is specific to Tiktok rotation
    captcha. For the conversion calculation refer to tiktok website with captcha.

    Args:
        angle : the angle of rotation of the image

    Returns:
        pixel : angle converted into pixel
    '''
    # pixel = 1.52 * angle
    pixel = 2.3 * angle
    return pixel


def _tiktok_captcha_rotate(outer_image_path, inner_image_path, folder_path):
    '''
    Takes in the outer ring and inner circle image and finds the angle of rotation.
    Note - Does not always gives the correct angle. 

    Args:
        outer_image : outer ring image path of the rotating captcha
        inner_image : inner circle image path of the rotating captcha
        folder_path : output folder to save the corrected image

    Returns:
        best_angle : the angel of rotation to correct the captcha
        corrected_image_path : the path of the corrected image 
    '''

    # Read inner and outer image. Combine both the images
    outer_ring = cv2.imread(outer_image_path, cv2.IMREAD_UNCHANGED)
    inner_circle = cv2.imread(inner_image_path, cv2.IMREAD_UNCHANGED)

    best_angle = 0
    lowest_num_lines = float('inf')

    # Rotate image from 0 - 180 degrees
    for angle in range(0, 181):
        # rotate image, combine the images, check the number of lines in the image
        outer_ring_rotated, innner_circle_rotated = _rotate_image(
            outer_ring, inner_circle, angle)
        rotated_combined_image = _image_combiner(
            outer_ring_rotated, innner_circle_rotated)
        num_lines = _line_check(rotated_combined_image)

        # if the  number of lines are the least that would be the best angle of rotation in most cases
        if num_lines < lowest_num_lines:
            lowest_num_lines = num_lines
            best_angle = angle
            best_image = rotated_combined_image

    # save the rotated image
    corrected_image_path = os.path.join(folder_path, "captcha_corrected.png")
    cv2.imwrite(corrected_image_path, best_image)

    return best_angle, corrected_image_path


def _rotate_image(outer_ring, innner_circle, angle):
    '''
    Takes in the outer ring and inner circle image and rotates to the given angle.

    Args:
        outer_ring : outer ring image for rotation
        innner_circle : inner circle image for rotation
        angle : angle of rotation

    Returns:
        outer_ring_rotated : rotated outer ring image
        innner_circle_rotated : rotated inner circle image 
    '''

    # Define the rotation matrices for clockwise and counterclockwise rotations
    # (x, y), angle, scale
    ccw_rotation_matrix = cv2.getRotationMatrix2D(
        (outer_ring.shape[1] / 2, outer_ring.shape[0] / 2), angle, 1)
    cw_rotation_matrix = cv2.getRotationMatrix2D(
        (innner_circle.shape[1] / 2, innner_circle.shape[0] / 2), -angle, 1)

    # Apply the rotations to the images
    outer_ring_rotated = cv2.warpAffine(
        outer_ring,
        ccw_rotation_matrix,
        (outer_ring.shape[1],
         outer_ring.shape[0]))
    innner_circle_rotated = cv2.warpAffine(
        innner_circle,
        cw_rotation_matrix,
        (innner_circle.shape[1],
         innner_circle.shape[0]))
    return outer_ring_rotated, innner_circle_rotated


def _image_combiner(outer_ring, innner_circle):
    '''
    Combines the outer ring and inner circle image into 1 image.

    Args:
        outer_ring : outer ring image for rotation
        innner_circle : inner circle image for rotation

    Returns:
        base_img : combined image
    '''
    # Calculate the x, y coordinates where inner_circle should be placed on top of outer_ring
    x_offset = ((outer_ring.shape[1] - innner_circle.shape[1]) // 2)
    y_offset = ((outer_ring.shape[0] - innner_circle.shape[0]) // 2)

    # Create a copy of outer_ring to use as the base image
    base_img = outer_ring.copy()

    # Overlay inner_circle on top of the base image at the specified coordinates
    base_img[y_offset:y_offset +
             innner_circle.shape[0], x_offset:x_offset +
             innner_circle.shape[1]] = cv2.add(outer_ring[y_offset:y_offset +
                                                          innner_circle.shape[0], x_offset:x_offset +
                                                          innner_circle.shape[1]], innner_circle)

    # Display the resulting image
    # cv2.imshow('Result', base_img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    return base_img


def _line_check(base_img):
    '''
    Finds the number of lines in given image

    Args:
        base_img : input image

    Returns:
        num_of_lines : the number if lines in the image
    '''
    num_of_lines = 0

    # image that will be used to draw the lines only
    line_image = base_img.copy()

    # convert the image to gray
    gray = cv2.cvtColor(base_img, cv2.COLOR_BGR2GRAY)

    # add median blur to image
    blur_base_img = cv2.medianBlur(gray, 9)

    # find the number of edges
    edges = cv2.Canny(blur_base_img, 1250, 1510, apertureSize=5)

    # Use HoughlinesP to find the number of lines
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=10,
        minLineLength=100,
        maxLineGap=225)

    # Draw the lines on the image
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(line_image, (x1, y1), (x2, y2), (0, 0, 255), 1)
    else:
        return num_of_lines

    num_of_lines = len(lines)

    # show image lines
    # cv2.imshow("Img_Edges", edges)
    # cv2.imshow("Lines", line_image)
    # cv2.waitKey(0)

    return num_of_lines

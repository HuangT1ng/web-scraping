
import os
import re
import time
import json
import csv
import random
import requests
import math
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List
from bs4 import BeautifulSoup
from datetime import datetime, timedelta



# Scraping with selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    WebDriverException, TimeoutException,
    NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException)

from tiktok_captcha import solve_captcha_if_present
from chrome_utils import create_driver

def extract_date(comment_container_element_xpath, driver):
    try:
        comment_container_element = driver.find_element(By.XPATH, comment_container_element_xpath)
        date_xpath = "./div/div[1]/div[1]"
        date_element = comment_container_element.find_element(By.XPATH, date_xpath)
        text = date_element.text
        date_pattern = r'(\d{4})-(\d{1,2})-(\d{1,2})'

        # Search for the date in the text
        match = re.search(date_pattern, text)

        if match:
            # Extract the date components
            year, month, day = map(int, match.groups())
            
            # Create a datetime object
            date_time = datetime(year, month, day)
            return date_time
    except: 
        print('date extraction error')
        return None

def extract_all_images(driver):
    """
    Extracts all image URLs from a specific element.
    
    Args:
        driver: The Selenium WebDriver instance.
        element_xpath: The XPath of the parent element containing the images.

    Returns:
        A list of image URLs.
    """
    try:
        PhotoVideoContainer_element = driver.find_element(By.XPATH, "//*[contains(@class, 'DivPhotoVideoContainer')]")

        # Find all image elements within the photo container element
        images = PhotoVideoContainer_element.find_elements(By.TAG_NAME, 'img')
        
        # Extract the 'src' attribute from each image element
        image_urls = [img.get_attribute('src') for img in images]
        
        return image_urls
    except:
        print(' no images found')
        return None

def extract_caption(driver):
    """
    Extracts all text from <span> elements under the specified data attribute.
    
    Args:
        driver: The Selenium WebDriver instance.

    Returns:
        A list of strings containing the text from each <span> element.
    """
    # Find the caption element by data attribute
    caption_element = driver.find_element(By.XPATH, "//*[@data-e2e='browse-video-desc']")
    
    # Find all <span> elements within the caption  element
    spans = caption_element.find_elements(By.TAG_NAME, 'span')
    
    # Extract the text from each <span> element and filter out empty strings
    captions = [span.text for span in spans if span.text.strip()]

    # Join the non-empty captions into a single string
    return ' '.join(captions)

def extract_photo_view_count(driver):
    """
    Extracts photo IDs and view counts from the user post item list.

    Args:
        driver: The Selenium WebDriver instance.

    Returns:
        A list of dictionaries containing photo IDs and view counts.
    """
    # Find the  element containing user posts
    user_post_list = driver.find_element(By.XPATH, "//*[@data-e2e='user-post-item-list']")
    
    # Find all child elements within the user post list
    posts = user_post_list.find_elements(By.XPATH, "./*")  # Adjust XPath if needed
    
    all_photo_view_counts = []

    for post in posts:
        # Extract the link from the post (assuming it is a child anchor tag)
        link_element = post.find_element(By.TAG_NAME, 'a')  # Adjust if the link is in a different tag
        post_link = link_element.get_attribute('href')
        
        # Extract the ID from the link
        if "photo/" in post_link:
            photo_id = post_link.split("photo/")[-1]
            
            # Extract the view count
            view_count_element = post.find_element(By.XPATH, ".//*[@data-e2e='video-views']")
            view_count = view_count_element.text
            
            # Append the data as a dictionary
            all_photo_view_counts.append({
                'photo_id': photo_id,
                'view_count': view_count
            })

    return all_photo_view_counts

def get_view_count_by_photo_id(photo_id, photo_data):
    """
    Retrieves the view count for a specific photo ID.

    Args:
        photo_id: The ID of the photo to search for.
        photo_data: The list of dictionaries containing photo IDs and view counts.

    Returns:
        The view count as a string, or 'Not Found' if the ID doesn't exist.
    """
    for photo in photo_data:
        if photo['photo_id'] == photo_id:
            return photo['view_count']
    return 'Not Found'

def extract_likes_comment_save(driver):
    """
    Extracts likes, comments, and saves from a specified content container.

    Args:
        driver: The Selenium WebDriver instance.

    Returns:
        A dictionary containing likes, comments, and saves.
    """
    # Find the content container using class that contains 'DivContentContainer'
    content_container = driver.find_element(By.XPATH, "//*[contains(@class, 'DivContentContainer')]")

    try:
        # Extract likes from the specified data-e2e attribute
        likes_element = content_container.find_element(By.XPATH, "//*[@data-e2e='browse-like-count']")
        like_count = likes_element.text

        # Extract comment count
        comments_element = content_container.find_element(By.XPATH, "//*[@data-e2e='browse-comment-count']")
        comment_count = comments_element.text

        # Extract saves
        saves_element = content_container.find_element(By.XPATH, "//*[@data-e2e='undefined-count']")
        save_count = saves_element.text

    except Exception as e:
        print(f"Error extracting engagement data: {e}")
        return None

    return int(like_count), int(comment_count), int(save_count)

def convert_datetime_to_string(data):
    for item in data:
        for key, value in item.items():
            if isinstance(value, datetime):
                item[key] = value.isoformat()  # Convert datetime to ISO format
    return data

def convert_json_to_csv(data):
    # Convert datetime objects to string format
    data = convert_datetime_to_string(data)

    # Specify the CSV file name
    csv_file_name = "tiktok_scrape_result.csv"
    
    # Check if data is provided
    if not data:
        print("No data provided.")
        return

    # Convert data to JSON format (just for representation)
    json_data = json.dumps(data, indent=4)
    print("Converted data to JSON format:\n", json_data)

    # Save as CSV
    keys = data[0].keys()
    with open(csv_file_name, mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=keys)
        writer.writeheader()
        for row in data:
            writer.writerow(row)

    print(f"Data has been saved to {csv_file_name}.")
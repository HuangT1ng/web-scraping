import os
import shutil

# give access to enter key, esc key, etc. to type smth in search bar
from selenium.webdriver import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# to add more specific exceptions if needed
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from PIL import Image, ImageDraw

import time
import logging as logger
# from logging_comfig import TT_Pub_AM_c_logger as logger
import cv2
import urllib.request
import pyautogui
import numpy as np
import re
import requests


import scipy.interpolate as si

# Path to tiktok folder
MODULE_PATH = os.path.dirname(os.path.abspath(__file__))

def solve_captcha_if_present(driver: Chrome):
    # captcha checker (jigsaw)
    jigsaw_presence = re.search(r'Drag the \w{0,30}puzzle',driver.page_source,re.IGNORECASE)
    captcha_presence = re.search(r'captcha',driver.page_source,re.IGNORECASE)

    # print(driver.page_source)

    print(f"jisg {jigsaw_presence}")
    print(f"cap {captcha_presence}")

    if (jigsaw_presence is not None) and (captcha_presence is not None):
        tiktok_captcha_bypass_jigsaw(driver)
        return

    # captcha checker (rotation)
    try:
        WebDriverWait(driver, 10).until(EC.visibility_of_all_elements_located(
            (By.XPATH, '//div[text()="Drag the slider to fit the puzzle"]')))
    except TimeoutException:
        # logger.info("CAPTCHA WAS NOT PRESENT / CAPTCHA WAS NOT LOADED")
        print("CAPTCHA WAS NOT PRESENT / CAPTCHA WAS NOT LOADED")
        return
    except:
        logger.exception("captcha check error")
        print("captcha check error")
        return
    else:
        # time.sleep(30)
        # print ("rotation")
        try:
            tiktok_captcha_bypass_rotation(driver, os.path.join(MODULE_PATH, "captcha_images"))
        except Exception as e:
            print ("rotation failed:", e)
        
        time.sleep(5)
        if (jigsaw_presence is not None) and (captcha_presence is not None):
            tiktok_captcha_bypass_jigsaw(driver)
            return
        # folder_path = '/home/s4q1/Desktop/tiktok/captcha_images'
        # for filename in os.listdir(folder_path):
        #     file_path = os.path.join(folder_path, filename)
        #     try:
        #         if os.path.isfile(file_path) or os.path.islink(file_path):
        #             os.unlink(file_path)
        #         elif os.path.isdir(file_path):
        #             shutil.rmtree(file_path)
        #     except Exception as e:
        #         print(f'Failed to delete {file_path}. Reason: {e}')
        

class JigsawPuzzleSolver:
    def __init__(self, piece_path, background_path):
        self.piece_path = piece_path
        self.background_path = background_path

    def get_position(self):
        template, x_inf, y_sup, y_inf = self.__piece_preprocessing()
        background = self.__background_preprocessing(y_sup, y_inf)

        res = cv2.matchTemplate(background, template, cv2.TM_CCOEFF_NORMED)
        
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        top_left = max_loc
        h,w = template.shape[::1]
        h2,w2 = background.shape[::1]
        
        #print(template.shape)
        bottom_right = (top_left[0]+w,top_left[1]+h)
        cv2.rectangle(background,top_left,bottom_right,255,2)
        cv2.imwrite("captcha_result.png",background)       
        x_centroid =  top_left[0]+round(w/2,0)

        return x_centroid,w2

    def __background_preprocessing(self, y_sup, y_inf):
        background = self.__sobel_operator(self.background_path)

        return background

    def __piece_preprocessing(self):
        img = self.__sobel_operator(self.piece_path)
        x, w, y, h = self.__crop_piece(img)
        template = img[y:h, x:w]

        return template, x, y, h

    def __crop_piece(self, img):
        white_rows = []
        white_columns = []
        r, c = img.shape

        for row in range(r):
            for x in img[row, :]:
                if x != 0:
                    white_rows.append(row)

        for column in range(c):
            for x in img[:, column]:
                if x != 0:
                    white_columns.append(column)

        x = white_columns[0]
        w = white_columns[-1]
        y = white_rows[0]
        h = white_rows[-1]

        return x, w, y, h

    def __sobel_operator(self, img_path):
        scale = 1
        delta = 0
        ddepth = cv2.CV_16S

        img = cv2.imread(img_path, cv2.IMREAD_COLOR)
        img = cv2.GaussianBlur(img, (3, 3), 0)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        grad_x = cv2.Sobel(gray, ddepth, 1, 0, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)
        grad_y = cv2.Sobel(gray, ddepth, 0, 1, ksize=3, scale=scale, delta=delta, borderType=cv2.BORDER_DEFAULT)
        abs_grad_x = cv2.convertScaleAbs(grad_x)
        abs_grad_y = cv2.convertScaleAbs(grad_y)
        grad = cv2.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)

        return grad


def download_image(url,file_name):
    try:
        response = requests.get(url,stream=True)
    except:
        print("Unable to download image {} @ {}".format(file_name,url))
        return
    else:
        with open(file_name,"wb") as f:
            shutil.copyfileobj(response.raw,f)    

def get_points(x_centroid_rd):
    # Curve base:
    points = [[0, 0], [0, 2], [round(0.2*x_centroid_rd,0), 3], [round(0.5*x_centroid_rd,0), 0], [round(0.8*x_centroid_rd,0), 3], [x_centroid_rd, 2], [x_centroid_rd, 0]]
    points = np.array(points)

    x = points[:,0]
    y = points[:,1]

    t = range(len(points))
    ipl_t = np.linspace(0.0, len(points) - 1, 20)

    x_tup = si.splrep(t, x, k=3)
    y_tup = si.splrep(t, y, k=3)

    x_list = list(x_tup)
    xl = x.tolist()
    x_list[1] = xl + [0.0, 0.0, 0.0, 0.0]

    y_list = list(y_tup)
    yl = y.tolist()
    y_list[1] = yl + [0.0, 0.0, 0.0, 0.0]


    x_i = si.splev(ipl_t, x_list) # x interpolate values
    delta_x_i = [round(x_i[i]-x_i[i-1],0) for i in range(1,len(x_i))]
    y_i = si.splev(ipl_t, y_list) # y interpolate values
    delta_y_i = [round(y_i[i]-y_i[i-1],0) for i in range(1,len(y_i))]
    total_delta_x = sum(delta_x_i[:-1])
    delta_x_i[-1] = x_centroid_rd - total_delta_x
    
    return zip(delta_x_i,delta_y_i)

def tiktok_captcha_bypass_jigsaw(driver):
    print('Jigsaw')
    captcha_bg_elem = driver.find_element(By.XPATH, "//img[@id='captcha-verify-image']")
    captcha_bg = captcha_bg_elem.get_attribute("src")
    captcha_puzzle_elem = driver.find_element(By.XPATH, "//img[contains(@class,'captcha_verify_img_slide')]")
    captcha_puzzle = captcha_puzzle_elem.get_attribute("src") 
    download_image(captcha_bg,"captcha_bg.png")
    download_image(captcha_puzzle,"captcha_puzzle.png")

    a = JigsawPuzzleSolver("captcha_puzzle.png","captcha_bg.png")
    x_centroid_pixels,bg_width = a.get_position()
    print(x_centroid_pixels,bg_width,round(x_centroid_pixels/bg_width,1))

    arrow_elem = driver.find_element(By.XPATH, "//div[contains(@class,'captcha-drag-icon')]")

    x_centroid = (x_centroid_pixels/bg_width)*captcha_bg_elem.size['width'] - (arrow_elem.size['width']/2)
    print(x_centroid)
    x_centroid_rd = round(x_centroid,0)
    print(x_centroid_rd)

    action = ActionChains(driver).click_and_hold(arrow_elem)

    coords = get_points(x_centroid_rd)
    for mouse_x,mouse_y in coords:
        action.move_by_offset(mouse_x,mouse_y)
        action.perform()
        print(mouse_x,mouse_y)

    action.pause(3).release().perform()
    time.sleep(5)
    
    return

def tiktok_captcha_bypass_rotation(driver, folder_path):
    '''
    Function to bypass tiktok rotation captcha.

    Args:
        driver : the webdriver
        folder_path : path to save the details of the images for correction

    Returns:
        is_solved : boolean to check if captcha has been bypassed
    '''

    is_solved = False
    # Used to get the id of the captcha container
    element = driver.find_element(
        By.XPATH, '//div[contains(@class,"captcha")]')
    parent_element = element.find_element(By.XPATH, '..')
    xpath_id = parent_element.get_attribute('id')
    logger.debug(f"id is {xpath_id}")

    loop_counter = 0
    MAX_TIKTOK_BYPASS_ATTEMPT = 8
    MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT = 5
    WEBDRIVER_WAIT_TIME = 10

    # loop until max attempt
    while loop_counter < MAX_TIKTOK_BYPASS_ATTEMPT:
        logger.info("CAPTCHA PRESENT")

        # Find the elements of the 2 images of the captcha, refresh the image if not loaded
        for i in range(MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT):
            # Check if the outer image is loaded. Generally if the first image is loaded the inner image will also be loaded
            try:
                WebDriverWait(driver, 3).until(
                    EC.visibility_of_all_elements_located(
                        (By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[1]')))
            except TimeoutException:
                logger.debug("Captcha image loading timeout")

            # Find the element of the respective images for downloading
            try:
                captcha_outer_ring = driver.find_element(
                    By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[1]')
                captcha_inner_circle = driver.find_element(
                    By.XPATH, f'//*[@id="{xpath_id}"]/div/div[2]/img[2]')
                break
            except NoSuchElementException:
                # Image to be refreshed if the element is not found
                logger.error("Captcha Image Xpath not found! Refreshing...")
                refresh_button = driver.find_element(
                    By.XPATH, f'//span[text()="Refresh"]')
                refresh_button.click()
            except BaseException:
                logger.exception("Unexpected Captcha Image Error")
                return is_solved
        else:
            logger.error(
                f"Could not find Captcha Image Xpath after {MAX_TIKTOK_IMAGE_REFRESH_ATTEMPT} tries...")
            return is_solved

        img_tags = [captcha_outer_ring, captcha_inner_circle]
        img_path = []

        # Download the inner and outer image
        for i, img_tag in enumerate(img_tags):
            img_src = img_tag.get_attribute('src')

            # Filename for outering and innner circle respectively
            if i == 0:
                filename = os.path.join(folder_path, f'captcha_outer.png')
                filename_attempt = os.path.join(
                    folder_path, f'attempt_{loop_counter}_captcha_outer.png')
                img_path.append(filename)
            elif i == 1:
                filename = os.path.join(folder_path, f'captcha_inner.png')
                filename_attempt = os.path.join(
                    folder_path, f'attempt_{loop_counter}_captcha_inner.png')
                img_path.append(filename)
            else:
                # filename = os.path.join(folder_path,f'captcha_image_{i}.png')
                logger.error("unexpected number of images")
                return is_solved

            # Download the images using urlib
            try:
                urllib.request.urlretrieve(img_src, filename)
            except BaseException:
                logger.exception("Error downloading image")
                return is_solved

            # shutil.copy(filename, filename_attempt)

        # Angle correction & angle to pixel conversion
        best_angle, corrected_image_filename = _tiktok_captcha_rotate(
            img_path[0], img_path[1], folder_path)
        corrected_image_filename_attempt = os.path.join(
            folder_path, f'attempt_{loop_counter}_captcha_corrected.png')
        shutil.copy(corrected_image_filename, corrected_image_filename_attempt)
        pixel = _angle_to_pixel(best_angle)
        print(f"Angle: {best_angle} degrees \t Pixel: {pixel} px")
        # print ("angle",best_angle)
        # print ("pixel",pixel)
        # time.sleep(300)

        # Check if slider is ready
        try:
            # slider = WebDriverWait(driver, WEBDRIVER_WAIT_TIME).until(EC.visibility_of_all_elements_located(
            #     (By.XPATH, '//div[@class="secsdk-captcha-drag-icon sc-kEYyzF fiQtnm"]')))
            slider = driver.find_element(By.XPATH,"//div[@class='secsdk-captcha-drag-icon sc-hMqMXs VZMN']")
            # print ("slider found")
        except Exception:
            print ("Slider could not be found")
            logger.exception("error")
            return is_solved
        else:
            time.sleep(3)
            # Find slider element
            try:
                slider = driver.find_element(
                    By.XPATH, '//*[@id="secsdk-captcha-drag-wrapper"]/div[2]/div')
                # print ("slider found 2")
            except Exception:
                print ("Slider could not be found2")
                logger.exception("slider location error")
            else:
                # Find the sliding button and slide
                # slider_image = os.path.join(os.getcwd(), 'cfg', 'slider.png')
                slider_image = os.path.join(MODULE_PATH, 'slider.png')
                # slider_image = os.path.join(MODULE_PATH, 'slider_arrow.png')
                # slider_location = pyautogui.locateCenterOnScreen(
                #     slider_image, confidence=0.7)

                # logger.info(f"Found slider at {slider_location}")

                '''
                Here uses ActionChains to drag the slider (Cannot one short drag all the way, need to drag it across a certian time, simulating human)
                Divides the pixels up into steps and slowly drag across it
                The captcha is tried max 20 times to solve, not a one time solve
                '''
                action = ActionChains(driver).click_and_hold(slider)

                duration = 2
                steps =10

                delay = duration/steps
                pixels_per_step = pixel /steps

                for _ in range(steps):
                    action.move_by_offset(pixels_per_step, 0)
                    action.perform()
                    time.sleep(delay)

                action.pause(3).release().perform()
                time.sleep (1)
                
                # if slider_location is not None:
                #     x, y = slider_location
                #     # print (x,y)
                #     # # pyautogui.alert(f"The mouse is now at position ({x}, {y})")
                #     # # emulate mouse movement
                #     # # pyautogui.moveTo(540, 592)
                #     # pyautogui.moveTo(x, y)
                #     # pyautogui.mouseDown()
                #     # # pyautogui.dragTo(x + pixel, y, duration=5)
                #     # pyautogui.drag(pixel, 0, duration=3)
                #     # pyautogui.mouseUp()
                    
                # else:
                #     logger.error("Unable to find slider")
                #     print ("completely cannnot find slider")
                #     return is_solved

        time.sleep(3)

        # Check if captcha still exists
        try:
            driver.find_element(By.XPATH, f'//*[@id="{xpath_id}"]/div')
        except NoSuchElementException:
            logger.info("Captcha cleared")
            is_solved = True
            return is_solved
        else:
            logger.info("Captcha still exists")
            loop_counter = loop_counter + 1

            if loop_counter % 5 == 0:
                logger.info("refreshing page")
                driver.refresh()
            if loop_counter >= MAX_TIKTOK_BYPASS_ATTEMPT:
                logger.error(
                    f"Captcha tried {MAX_TIKTOK_BYPASS_ATTEMPT} times, unable to solve...")
                return is_solved


def _angle_to_pixel(angle):
    '''
    To convert the angle given in to pixel. This is specific to Tiktok rotation
    captcha. For the conversion calculation refer to tiktok website with captcha.

    Args:
        angle : the angle of rotation of the image

    Returns:
        pixel : angle converted into pixel
    '''
    # pixel = 1.52 * angle
    pixel = 1.55 * angle
    # pixel = 2.3 * angle
    # pixel = 2.1 * angle
    return pixel


def _tiktok_captcha_rotate(outer_image_path, inner_image_path, folder_path):
    '''
    Takes in the outer ring and inner circle image and finds the angle of rotation.
    Note - Does not always gives the correct angle. 

    Args:
        outer_image : outer ring image path of the rotating captcha
        inner_image : inner circle image path of the rotating captcha
        folder_path : output folder to save the corrected image

    Returns:
        best_angle : the angel of rotation to correct the captcha
        corrected_image_path : the path of the corrected image 
    '''

    # Read inner and outer image. Combine both the images
    outer_ring = cv2.imread(outer_image_path, cv2.IMREAD_UNCHANGED)
    inner_circle = cv2.imread(inner_image_path, cv2.IMREAD_UNCHANGED)
    print(f"OR SHAPE: {outer_ring.shape}")
    print(f"IC SHAPE: {inner_circle.shape}")
    # cv2.imshow('Outer Ring', outer_ring)
    # cv2.waitKey(2000)
    # cv2.imshow('inner circle', inner_circle)
    # cv2.waitKey(2000)
    # cv2.destroyAllWindows()
    


    best_angle = 0
    lowest_num_lines = float('inf')

    # Rotate image from 0 - 180 degrees
    for angle in range(1, 179):
        # rotate image, combine the images, check the number of lines in the image
        outer_ring_rotated, innner_circle_rotated = _rotate_image(
            outer_ring, inner_circle, angle)
        rotated_combined_image = _image_combiner(
            outer_ring_rotated, innner_circle_rotated)
        num_lines = _line_check(rotated_combined_image)

        # if the  number of lines are the least that would be the best angle of rotation in most cases
        print ("Num lines",num_lines)
        print ("lowest",lowest_num_lines)
        print ( best_angle)
        print (angle)
        if num_lines < lowest_num_lines:
            lowest_num_lines = num_lines
            best_angle = angle
            best_image = rotated_combined_image
            # cv2.imshow('Result', best_image)
            # cv2.waitKey(0)
            # cv2.destroyAllWindows()
    print ("---------End----------")
    # save the rotated image
    corrected_image_path = os.path.join(folder_path, "captcha_corrected.png")
    cv2.imwrite(corrected_image_path, best_image)

    return best_angle, corrected_image_path


def _rotate_image(outer_ring, innner_circle, angle):
    '''
    Takes in the outer ring and inner circle image and rotates to the given angle.

    Args:
        outer_ring : outer ring image for rotation
        innner_circle : inner circle image for rotation
        angle : angle of rotation

    Returns:
        outer_ring_rotated : rotated outer ring image
        innner_circle_rotated : rotated inner circle image 
    '''

    # Define the rotation matrices for clockwise and counterclockwise rotations
    # (x, y), angle, scale
    ccw_rotation_matrix = cv2.getRotationMatrix2D(
        (outer_ring.shape[1] / 2, outer_ring.shape[0] / 2), angle, 1)
    cw_rotation_matrix = cv2.getRotationMatrix2D(
        (innner_circle.shape[1] / 2, innner_circle.shape[0] / 2), -angle, 1)

    # Apply the rotations to the images
    outer_ring_rotated = cv2.warpAffine(
        outer_ring,
        ccw_rotation_matrix,
        (outer_ring.shape[1],
         outer_ring.shape[0]))
    innner_circle_rotated = cv2.warpAffine(
        innner_circle,
        cw_rotation_matrix,
        (innner_circle.shape[1],
         innner_circle.shape[0]))
    return outer_ring_rotated, innner_circle_rotated


def _image_combiner(outer_ring, inner_circle):
    '''
    Combines the outer ring and inner circle image into 1 image.

    Args:
        outer_ring : outer ring image for rotation
        innner_circle : inner circle image for rotation

    Returns:
        base_img : combined image
    '''

    inner_circle_pil = Image.fromarray(cv2.cvtColor(inner_circle, cv2.COLOR_BGR2RGBA))
    outer_ring_pil = Image.fromarray(cv2.cvtColor(outer_ring, cv2.COLOR_BGR2RGBA))

    assert inner_circle_pil.size == (211, 211), f"Image must be of size (211, 211). Current size: {inner_circle_pil.size}"


    # Remove the white background
    datas = inner_circle_pil.getdata()
    new_data = []
    for item in datas:
        # Change all white (also shades of whites)
        # pixels to transparent
        if item[:3] == (255, 255, 255):
            new_data.append((255, 255, 255, 0))
        else:
            new_data.append(item)
    
    inner_circle_pil.putdata(new_data)

    # Calculate the x, y coordinates where inner_circle should be placed on top of outer_ring
    x_offset = (outer_ring_pil.width - inner_circle_pil.width) // 2
    y_offset = (outer_ring_pil.height - inner_circle_pil.height) // 2
    print(f"x off: {x_offset}, y off: {y_offset}. Out: {outer_ring_pil.size} in: {inner_circle_pil.size}")

    # Paste the inner circle on the outer ring using the calculated offsets
    outer_ring_pil.paste(inner_circle_pil, (x_offset, y_offset), inner_circle_pil)

    # Convert the final image back to an OpenCV image
    base_img = cv2.cvtColor(np.array(outer_ring_pil), cv2.COLOR_RGBA2BGRA)

    # # Show the final image using OpenCV
    # cv2.imshow('Final Image', base_img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    return base_img


def _line_check(base_img):
    '''
    Finds the number of lines in given image

    Args:
        base_img : input image

    Returns:
        num_of_lines : the number if lines in the image
    '''
    num_of_lines = 0

    # image that will be used to draw the lines only
    line_image = base_img.copy()

    # convert the image to gray
    gray = cv2.cvtColor(base_img, cv2.COLOR_BGR2GRAY)

    # add median blur to image
    blur_base_img = cv2.medianBlur(gray, 9)

    # find the number of edges
    edges = cv2.Canny(blur_base_img, 1250, 1510, apertureSize=5)

    # Use HoughlinesP to find the number of lines
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=10,
        minLineLength=100,
        maxLineGap=225)

    # Draw the lines on the image
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(line_image, (x1, y1), (x2, y2), (0, 0, 255), 1)
    else:
        return num_of_lines

    num_of_lines = len(lines)

    # show image lines
    # cv2.imshow("Img_Edges", edges)
    # cv2.imshow("Lines", line_image)
    # cv2.waitKey(0)

    return num_of_lines

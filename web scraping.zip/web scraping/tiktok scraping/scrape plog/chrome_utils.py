"""
Utils for creating Chrome Webdriver using Selenium.
Modify CHROMEDRIVER_PATH, USER_DATA_DIR & USER_PROFILES for respective system.

Update 22 Aug 2023: Has been edited for inclusion of Firefox (Instagram) and Edge (Tiktok).
"""
import asyncio
import random
import time

from selenium import webdriver
from selenium.webdriver import Chrome, Edge, Firefox
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions

from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.edge.options import Options as EdgeOptions

from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile

from selenium.common.exceptions import WebDriverException
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager



import logging

logger = logging.getLogger(__name__)

# Env specific paths
# chromedriver_path
#     path to installed chromedriver executable
# CHROME_USER_DATA_DIR
#     path to chrome user data as shown in 'chrome://version' (minus the profile),
#     eg. "...\AppData\Local\Google\Chrome\User Data"
# CHROME_USER_PROFILE
#     list of user profiles to use when accessing chrome
#     eg. Default, Profile 1 etc.
#     Will be in the folder specified in CHROME_USER_DATA_DIR


# FIREFOX_PROFILE_DIR
#     Path to the root user profile directory for firefox. Can be accessed from about:profiles in Firefox URL Search Bar.
#     Should be named xxxxxxx.xxxxxxxx
#     i.e. C:\Users\{INSERT USER HERE}\AppData\Roaming\Mozilla\Firefox\Profiles\iaj1h2w9.Keialth

# EDGE_USER_DATA_DIR
#     path to chrome user data as shown in 'edge://version' (minus the profile),
#     eg. "C:\\Users\\{INSERT USER HERE}\\AppData\\Local\\Microsoft\\Edge\\User Data"
#     !!! EXTREMELY RECOMMENDED TO DUPLICATE "User Data" TO "User Data1" (...\AppData\Local\Google\Chrome\User Data1) because Edge likes to run in the background.
# EDGE_USER_PROFILE
#     list of user profiles to use when accessing edge
#     eg. Profile 1, Profile 2 etc.
#     Will be in the folder specified in EDGE_USER_DATA_DIR

# NOTE: fill this with environment-specific paths
CHROMEDRIVER_PATH = r"/home/q1/Desktop/SOMO - 24Aug2023 (Comm Bot)/chromedriver_linux64/chromedriver"
FIREFOXDRIVER_PATH = r"/home/s4q1/.cache/mozilla/firefox/xy6juep0.default"
EDGEDRIVER_PATH = r"/home/s4q1/.config/microsoft-edge/Default"

COMPUTER_USER = "q1"
# CHROME_USER_NON_AVATAR = "Default"
CHROME_USER_PROFILE = "Profile 1" #chrome://version/
FIREFOX_PROFILE = "ys0psf82.lhg2" #about:profiles
EDGE_USER_PROFILE = "Profile 1" 

########## no need to configure the following
CHROME_USER_DATA_DIR = rf"/home/{COMPUTER_USER}/.config/google-chrome"
# CHROME_USER_DATA_DIR = rf"/home/{COMPUTER_USER}/.config/google-chrome"
FIREFOX_PROFILE_DIR = (
    rf"/home/s4q1/.mozilla/firefox/{FIREFOX_PROFILE}"

)
EDGE_USER_DATA_DIR = rf"/home/{COMPUTER_USER}/.config/microsoft-edge/Profile 1"

# Global lock as only one chromedriver can be open at any time
CHROME_LOCK = asyncio.Lock()


def create_driver(
    platform, set_user_data_dir=False, set_user_profile=False, headless=False
):
    """
    This function creates a selenium driver.
    By default, creates a pre-set user account.
    The driver to be created is as follows:
    Platform:
        1. Firefox: TiktokACC
        2. Edge: InstagramACC/InstagramURL
        3. Chrome: Everything else

    Parameters (Depreciated, inputting them does nothing)
    ---
    set_user_data_dir: bool = False
        if set to True, uses the user_data_dir set above
    set_user_profile: bool = False
        if set to True, uses a random user_profile from the list above
    headless: bool = False
        whether to run in headless mode

    Returns
    -------
    driver: WebDriver object

    Raises
    ------
    WebDriverException
        If instantiating the chrome driver object was unsuccessful
    """
    try:
        if platform == "TiktokACC":
            ser = FirefoxService()
            op = FirefoxOptions()
            op.add_argument("--incognito")
            op.page_load_strategy = 'normal'
            driver = Firefox(service=ser, options=op)

            # Firefox
            return driver

        elif platform == "InstagramACC" or platform == "InstagramURL":
    
            # Edge
            ser = EdgeService()
            op = EdgeOptions()
            #op.add_argument("--remote-debugging-port=4000")
            #op.add_argument("--no-sandbox")
            #op.add_argument("--use_chromium")
            #op.add_experimental_option("excludeSwitches", ["enable-logging"])
            #op.add_argument("--disable-gpu")
            #op.add_argument("--disable-dev-shm-usage")
            # op.binary_location(EDGE)
            #op.add_argument(rf"user-data-dir={EDGE_USER_DATA_DIR}")
            op.add_argument(rf"--profile-directory={EDGE_USER_PROFILE}")
            op.add_argument("--start-maximized")
            
            driver = Edge(service=ser, options=op)
            
            return driver

        else:
            # Use Chrome for everything else
            # If ChromeDriver has been downloaded
            # ser = ChromeService(CHROMEDRIVER_PATH)

            ser = ChromeService(CHROMEDRIVER_PATH)
            # ser = ChromeService()
            op = ChromeOptions()
            op.add_argument("--no-sandbox")
            op.add_argument("--disable-gpu")
            op.add_argument("--disable-dev-shm-usage")
            op.add_argument("--start-maximized")
            op.add_argument("--enable-print-browser")
            op.add_argument("--kiosk-printing")
            # op.add_argument("--incognito")

            # Disable warning outputs
            # op.page_load_strategy = 'eager'
            # op.add_experimental_option('detach', True)
            op.add_experimental_option("excludeSwitches", ["enable-logging"])

            op.add_argument(
                "user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
            )

            if headless:
                op.add_argument("--headless=new")

            # Set to specified user profile if passed in
            op.add_argument(rf"user-data-dir={CHROME_USER_DATA_DIR}")
            op.add_argument(rf"--profile-directory={CHROME_USER_PROFILE}")
            try:
                driver = Chrome(service=ser, options=op)
            except:
                try:
                    driver = Chrome(
                        service=ChromeService(ChromeDriverManager().install()),
                        options=op,
                    )

                except:
                    print("Please close all chrome browsers")
                    # exit()
            return driver

    except WebDriverException as e:
        logger.exception(
            "WebDriverException when creating Webdriver. Ensure all browsers are closed."
        )
        logger.exception(e)
        return None


def setup_auto_driver():
    options = ChromeOptions()

    options.add_argument(rf"--user-data-dir=C:\Users\{COMPUTER_USER}\AppData\Local\Google\Chrome\User Data") #e.g. C:\Users\You\AppData\Local\Google\Chrome\User Data
    options.add_argument(rf'--profile-directory={CHROME_USER_PROFILE}') #e.g. Profile 3s

    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument('--start-maximized')

    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.page_load_strategy = 'normal'

    browser_path = ChromeService()
    try:
        driver = webdriver.Chrome(service=browser_path, options=options)
    except:
        try:
            driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()),options=options)
        except:
            print("Please close all google chrome browsers")
            exit()

    return driver


def main():
    """Unit tests"""
    # driver = create_driver("TiktokACC")
    # scrape_datetime = datetime.now()
    # content = scrape_post_comments("https://www.tiktok.com/@raymondl88/video/7213331723981999367")
    # fullpath_json_file = write_to_output(scrape_datetime,content,"url")
    # print(fullpath_json_file)
    print("hello")
    try:
        # driver = create_driver("FbACC") 
        # driver = create_driver("TiktokACC")
        driver = create_driver("InstagramURL")

    except Exception as e:
        print(e)
    else:
        driver.get("https://www.facebook.com/")
        time.sleep(10)
        driver.close()

    
    



if __name__ == "__main__":
    main()

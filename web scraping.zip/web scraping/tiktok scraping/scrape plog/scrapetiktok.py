import os
import re
import time
import json
import random
import requests
import math
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from tiktok_utils import *


# Scraping with selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    WebDriverException, TimeoutException,
    NoSuchElementException, StaleElementReferenceException, ElementClickInterceptedException)

from tiktok_captcha import solve_captcha_if_present
from chrome_utils import create_driver


MODULE_PATH = os.path.dirname(os.path.abspath(__file__))

def display_inc(old, new):
    """Displays the percentage increase rounded to 0.5% if <100% and nearest integer if > 1--%."""
    
    if isinstance(old, str) or isinstance(new, str):
        old = int(old)
        new = int(new)

    if old == -1 or new == -1:
        return ""
    
    old, new = int(old), int(new)
    if old == 0:
        return "0.0%"
    perc_inc = ((new - old) / old) * 100
    perc_inc = math.floor(perc_inc / 0.5) * 0.5

    if perc_inc >= 100:
        return f"{int(perc_inc)}%"
    elif perc_inc >= 0.5:
        return f"{perc_inc}%" 
    else:
        return "0.0%"

# --- Scraping with Selenium driver + solve captcha if necessary --- #
def create_driver_scrape_tiktok_account(
        account: str, last_scrape_time, max_posts: int = 100):
    """
    Creates a chromedriver using a random user profile to scrape a particular account.
    After scraping, quit the driver so a new driver can be created in the next scrape.
    """
    # If user does not specify a since_datetime, return most recent 5 posts 
    if not last_scrape_time:
        max_posts = 5

 
    try:
        driver = create_driver("TiktokACC")
        # logger.info('Creating web driver for TiktokACC')
        print('Creating web driver for TiktokACC')
        print(f"date : {last_scrape_time} ({type(last_scrape_time)})")
        posts = _scrape_tiktok_account_with_driver(
            driver, username=account, last_scrape_time=last_scrape_time, max_posts=max_posts)
        # logger.info
        print(f"Tiktok posts retrieved for {account}, quitting driver.")
        driver.quit()
        return posts
    except WebDriverException:
        # Error creating driver
        # logger.exception("WebDriverException")
        print('wendriver error')
    except AttributeError:
        # driver=None, most likely due to multiple chrome browsers open
        # logger.exception
        print(
            "Driver is None, likely issue with creating driver. "
            "Ensure all chrome browsers are closed.")
    except:
        # logger.exception
        print("Unexpected exception occurred when scraping Tiktok posts.")
        driver.quit()

def extract_id_and_type(url):
    # Regular expression pattern to extract ID and type of post
    pattern = r'https://www.tiktok.com/@[^/]+/(video|photo)/(\d+)'
    
    # Match the pattern against the URL
    match = re.match(pattern, url)
    
    if match:
        post_type = match.group(1)
        post_id = match.group(2)
        return post_id, post_type
    else:
        return None, None
    
def click_next(driver):
    # check if the arrow-right button to go to next post exist
    next_button = driver.find_element(
        By.XPATH, '//button[@data-e2e="arrow-right"]')

    # generate random value to let program sleep, to wait for page to load
    random_float = random.uniform(0.10, 1.00)
    time.sleep(random_float)

    if next_button.is_enabled():  # if next button is enabled
        WebDriverWait(driver, 10).until(EC.element_to_be_clickable)
        # logger.info
        # print('clicked on next post')
        try:
            time.sleep(1)
            login_container = driver.find_element(By.XPATH, "//div[contains(text(), 'Continue as guest')]")
            if login_container is not None:
                print('###########loginContainer')
                # login_container.click()
                input('press enter when done continue as guest')
        except NoSuchElementException:
            pass
        # print('clicked on next post') 
    
    return next_button.is_enabled()

def _scrape_tiktok_account_with_driver(
        driver: webdriver.Firefox, username, last_scrape_time, max_posts=5):
    """
    This function gets details of new tiktok uploads (upload link, upload date, number of likes and comments).

    Parameters:
    -------
    profile_directory_list: list
        The list of chrome profiles to select from

    Returns
    -------
     driver : Chrome WebDriver object

    username : str
        The tiktok user to monitor

    since_datetime: str
        Date of last monitored time, as a string, in UTC format (eg: '2023-02-28T16:24:18.000Z')

    max_post_to_return: int, optional
        Maximum number of post to return. (Eg: if there are 50 new post, but max_post_to_return is set to 30, only the 30 most recent post will be returned.)
        By default, max_post_to_return is set to -1, which indicates there is no max limit set. The function will return all posts that are posted after the last monitored date.

    Returns
    -------
    post_links : list
        The list of json objects. Each json object contains the details of one tiktok post.
        Fields: link, date, likes (count), comments (count)
    ```
    Sample payload:
    [
        {'link': 'https://www.tiktok.com/@raymondl88/video/7210632777077706002', 'date': '2023-03-15 04:57:50', 'likes': '42', 'comments': '10'},
        ...
    ]
    ```

    Raises
    ------
    StaleElementReferenceException
        If an element reference is stale (i.e., no longer attached to the DOM).
    NoSuchElementException
        If an element could not be found on the page.
    TimeoutException
        If an operation times out before completion.
    WebDriverException
        If a general WebDriver error occurs that does not fit into any other exception category.
    """
    try:
        user_profile_url = f'https://www.tiktok.com/@{username}'
        posts = []

        driver.get(user_profile_url)
        time.sleep(3)

        # ensure chrome is active window so captcha can be solved
        # NOTE: fails sometimes
        driver.switch_to.window(driver.window_handles[0])

        # check for captcha and solve if present
        # logger.debug
        print("Checking for Tiktok captcha")
        # solve_captcha_if_present(driver)
        input("Press Enter after solving CAPTCHA...")

        time.sleep(3)

        # click on first post
        print("Attempting to click on first post")
        time.sleep(2)
        try:
            element = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(
                (By.XPATH, f"(//a[contains(@href, 'https://www.tiktok.com/@{username}/photo/')])[1]//strong")))
        except TimeoutException as e:
            print("Element timed out!")
            # If element is not clickable, we remove the popup
 
            # The popup should have a div with innerHTML being Continue as guest
            print("Trying to find popup...\n")
            time.sleep(2)
            try:
                popup = driver.find_element(By.XPATH, "//div[contains(text(), 'Continue as guest')]")
                popup.click()
                print("Popup clicked!\n\n")
            except NoSuchElementException:
                pass
            
            time.sleep(2)
            
            e = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(
                (By.XPATH, f"(//a[contains(@href, 'https://www.tiktok.com/@{username}/photo/')])[1]//strong")))
            
        
        post_elements = driver.find_elements(By.XPATH, f"//a[not(@title) and contains(@href, 'https://www.tiktok.com/@{username}/photo/')]")
        print( len(post_elements))
        for post_element in post_elements:
            post_text = post_element.text
            print("\nhref:", post_element.get_attribute("href"))

            if "Pinned" in post_text:
                print("this is a pinned post, skipping...")
                continue
            else:
                print("Not pinned, breaking...")
                # Scroll the element into view using JavaScript
                photo_element = post_element
                break
        
        driver.execute_script("arguments[0].scrollIntoView(true);", photo_element)

        all_photo_view_counts = extract_photo_view_count(driver)
        # print(all_photo_view_counts)
        
        try:
            photo_post = photo_element.find_element(By.XPATH,  ".//strong")
            print('photo post clicked')
        except:
            print("photo post click error")
        else:
            time.sleep(random.uniform(1, 3))
            photo_post.click()
        
        comment_container_xpath ="//*[@data-e2e='search-comment-container']"

        while True: 
            WebDriverWait(driver, 10).until(
                lambda d: "tiktok.com/@{}/".format(username) in d.current_url and (
                    "video" in d.current_url or "photo" in d.current_url
                )
            )
            
            # convert URL object to a string object
            current_url = str(driver.current_url)
            post_id, post_type = extract_id_and_type(current_url)
            if(post_type != 'photo'):
                next_button = driver.find_element( By.XPATH, '//button[@data-e2e="arrow-right"]')
                next_button.click()
                continue
            # print(f"url is: {current_url}\n id: {post_id}, type: {post_type}")
            photo_url = current_url

            
            # get photo id
            splitted_url = photo_url.rsplit("/", 1)
            photo_id = splitted_url[-1]

            # extract all details
            date_of_post = extract_date(comment_container_xpath,driver)
            photo_links = extract_all_images(driver)
            caption = extract_caption(driver)
            view_count = get_view_count_by_photo_id(photo_id, all_photo_view_counts)
            likes_comments_saves = extract_likes_comment_save(driver)
            # print('details extraction successful')

            if(likes_comments_saves != None):
                likes, comments, save_count = likes_comments_saves

            # Check that all required fields are not None and date_of_post is valid
            if (post_id is not None and
                post_type is not None and
                caption is not None and
                photo_links is not None and
                date_of_post is not None and
                likes is not None and
                comments is not None and
                view_count is not None and
                save_count is not None and
                (last_scrape_time is None or date_of_post > last_scrape_time)):
                
                # Create the post dictionary
                post = {
                    "post_id": post_id,
                    "post_type": post_type,
                    "content": caption,
                    "link": photo_links,
                    "post_date": date_of_post,
                    "likes": likes,
                    "comments": comments,
                    "views": view_count,
                    "saves": save_count
                }
                
                # Append the post to posts_data
                print(post)
                posts.append(post)

            if max_posts > 0 and len(posts) >= max_posts:
                print(f'number of new post has reached {max_posts}')
                break
                
            next_button_enabled = click_next(driver)
            # print('next_button_enabled', next_button_enabled)
            if next_button_enabled:
                next_button = driver.find_element( By.XPATH, '//button[@data-e2e="arrow-right"]')
                next_button.click()
                print("clicked on next post")
                continue
            elif not next_button_enabled:  # if next button is disabled
                print(
                    'current post is the last post. User has no more post')
                return posts
            else:
                print('There is an error accessing next post.')
                return posts

    except StaleElementReferenceException as se:
        # logger.exception
        print(f'scrape_tiktok_post StateElementRef Exception: {se}')
    except NoSuchElementException as ne:
        # logger.exception
        print(f'scrape_tiktok_post NoSuchElement Exception: {ne}')
    except TimeoutException as te:
        # logger.exception
        print(f'scrape_tiktok_post Timeout Exception: {te}')
    except WebDriverException as we:
        # logger.exception
        print(f'scrape_tiktok_post WebDriver Exception: {we}')
    else:
        # driver.get("chrome://newtab")
        return posts

def main():
    """Unit tests"""

    print("testing ground")

    # account = 'htxsg'
    account = 'photo_log'
    last_updated = datetime.now() - timedelta(hours=24)
    # last_scrape_time = datetime(2024, 4, 1)
    posts =create_driver_scrape_tiktok_account(account, last_scrape_time=None)
    convert_json_to_csv(posts)

if __name__ == "__main__":
    main()

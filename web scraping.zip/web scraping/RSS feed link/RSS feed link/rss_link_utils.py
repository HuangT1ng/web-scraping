from selenium.common.exceptions import WebDriverException, NoSuchElementException
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from bs4 import BeautifulSoup
import requests
import time

def initialize_chrome_driver():
    try:
        options = webdriver.ChromeOptions()
        
        COMPUTER_USER = 'q1'

        CHROME_USER_DATA_DIR = rf"/home/{COMPUTER_USER}/.config/google-chrome"
        
        # Add user-data directory argument
        options.add_argument(rf"user-data-dir={CHROME_USER_DATA_DIR}") 
        
        # Set profile directory 
        options.add_argument("profile-directory=Profile 1")   
        
        # Set a custom User-Agent
        options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36")
    
        # Initialize the Chrome driver with options
        driver = webdriver.Chrome(options=options)
        
        print("Chrome Driver initialized successfully.")
        return driver
    
    except WebDriverException as e:
        print(f"An error occurred while initializing ChromeDriver: {e}")
        return None

def format_url(query):
    return f'https://rssfinder.app/?q={query}'

def get_part_before_first_dot(query):
    # Split the string at the first occurrence of '.' and return the part before it
    return query.split('.')[0]


def extract_rss_links(driver, keyword):
    links = []
    try:
        sleep(5)
        # Find all <p> elements on the page
        paragraphs = driver.find_elements(By.TAG_NAME, 'p')
        # Iterate through each paragraph element
        for p in paragraphs:
            link = p.text
            if(keyword in link):
                links.append(link)

        return links

    except WebDriverException as e:
        print(f"WebDriver error occurred: {e}")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

def get_rss_links(url, driver):
    flag = 0
    # Open the specified URL
    driver.get(url)
    wait_for_all_elements_to_load(driver)
    # Retrieve the page source and find all <a> tags with "href"
    links = []
    elements = driver.find_elements(By.TAG_NAME, 'a')
    
    # Filter for links containing "rss" in the href attribute
    for element in elements:
        href = element.get_attribute('href')
        if href and 'rss' in href and href not in links:
            links.append(href)
    print(links)
    # Filter and process links
    for link in links[:]:  # Using a copy of the list to safely modify it inside the loop
        if link.endswith('.xml'):
            continue  # If the link already ends with .xml, do nothing and continue
        else:
            try:
                # Visit the link
                driver.get(link)
                wait_for_all_elements_to_load(driver)

                sleep(5)  # Wait for the page to fully load

                # Find new <a> tags on this page that contain "rss" and end with ".xml"
                new_elements = driver.find_elements(By.TAG_NAME, 'a')
                for new_element in new_elements:
                    new_href = new_element.get_attribute('href')
                    if  'rss' in new_href:
                        print(new_href)
                        links.append(new_href)
                        flag = 1
                if(flag == 1):                        
                    links.remove(link)
                    flag = 0

            
            except Exception as e:
                print(f"Error processing link {link}: {e}")
                continue  # If an error occurs, skip this link and continue

    return links


def wait_for_all_elements_to_load(driver,scroll_pause_time=2):

    last_height = driver.execute_script("return document.body.scrollHeight")

    # Set a limit for the number of scrolls to prevent infinite loops
    # Changeable
    max_scroll_attempts = 5  

    for attempt in range(max_scroll_attempts):
        try:


            # Wait for new elements to load after clicking
            time.sleep(scroll_pause_time)

        except NoSuchElementException:
            print("Loading...")

        # Scroll down to the bottom of the page
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

        # Wait for new elements to load (adjust scroll_pause_time if necessary)
        time.sleep(scroll_pause_time)

        # Check if the page height has changed
        new_height = driver.execute_script("return document.body.scrollHeight")

        if new_height == last_height:

            # If the height hasn't changed, break the loop
            break

        last_height = new_height
    else:
        print("Reached the maximum number of scroll attempts without detecting further changes.")